package DAO;

import org.omg.CORBA.OBJECT_NOT_EXIST;

/**
 * Events Database Access Object -
 * Here we will be able to update table rows,
 * delete rows,
 * or create new rows for various events that occur in the dead/alive person's life
 * mazel tov!
 */

public class EventsDatabaseAccess {
    /**
     * Remove a row in the events table
     *
     * - as it turns out uncle Bill did not actually die last year
     *
     * @param eventId - the numeric, unique id for the event
     *                (if the eventId does not exist it will not be deleted)
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removeEvent(int eventId) throws DataAccessException {
        return false;
    }

    /**
     * Add a new event (row) to the events table
     * updateEvent is then called with the rest of the object body
     *
     * - congratulations! It's a bouncing baby girl. You should probably not put your newborn on a trampoline tho
     *
     * @param eventDetails - object body that contains:
     *  eventId - numeric unique id associated with the event
     *               * @param latitude - latitude of the event
     *  latitude - the latitude of the event
     *  longitude - the longitude of the event
     *  country - the country where the event took place
     *  city - the city where the event took place
     *  eventType - event type
     *  year - type int, the year this event happened
     *  username - the descendant the event is connected to
     *  personId - the person that this event is about
     *                 (if the person does not exist the event will not be added)
     *
     *
     *@throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean addEvent(Object eventDetails) throws DataAccessException{
        return false;
    }
                //TODO do I need to have all the params here or in the update???

    /**
     * Update the table with added info
     *
     * @param eventDetails - object body that contains:
     *  eventId - numeric unique id associated with the event
     *               * @param latitude - latitude of the event
     *  latitude - the latitude of the event
     *  longitude - the longitude of the event
     *  country - the country where the event took place
     *  city - the city where the event took place
     *  eventType - event type
     *  year - type int, the year this event happened
     *  username - the descendant the event is connected to
     *  personId - the person that this event is about
     *             (if the person does not exist the event will not be added)
     *
     * if params are not NULL they are added to the row
     *
     * @throws DataAccessException
     *
     * @return Object body of event that was just updated
     */
    public Object updateEvent(Object eventDetails) throws DataAccessException {
        return null;
    }

    /**
     * Retrieves all the events associated with a specific username
     *
     * @param userDetails - an object body that contains:
     *  username - can be null as long as personId is not null
     *  personId - can be null as long as username is not null
     *
     * @return events - Arraylist of objects that contain all the data on events relating to user
     *
     * @throws DataAccessException
     */
    public Object[] getAllEvents(Object userDetails) throws DataAccessException {
        return null;
    }

    /**
     * retrieves a specific event based on an entered eventId
     *
     * @param eventId - numeric value associated with a specific event
     *
     * @return event - the single event associated with eventId
     *
     * @throws DataAccessException
     */
    public Object getEvent(int eventId) throws DataAccessException {
        return null;
    }

    /**
     * clears all the events from the table
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean clearAllEvents() throws DataAccessException {
        return false;
    }
}

// do I need a specific method for updating an individual column?

