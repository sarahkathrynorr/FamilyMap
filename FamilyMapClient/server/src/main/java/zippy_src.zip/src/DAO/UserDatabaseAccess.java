package DAO;

/**
 * Users Database Access Object -
 * Here we will be able to update table rows,
 * delete rows,
 * or create new rows for various users
 */

public class UserDatabaseAccess {
    /**
     * Add a new row in the user table
     *
     * @param userDetails - object body that contains:
     *  username - the username has to a unique non-null string
     *  password - the password is also non-null
     *  firstName - the first name of the new user, also non-null
     *  lastName - the last name of the new user, non-null
     *  gender - the gender ("m" or "f") non-null
     *
     * - if the user does not already exist as a person in the person table they are added using this information
     *               and a personId is assigned using the addPerson function from the PersonDatabaseAccess class
     *               //TODO will this be a problem??? ^^
     * calls AuthTokenDatabaseAccess addAuthToken(username)
     * @throws DataAccessException
     *
     * @return object body of new user that was just added
     */
    public Object addUser(Object userDetails) throws DataAccessException {
        return null;
    }

    /**
     * Remove a row from the user table
     *
     * @param userDetails - object body that contains username and password
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removeUser(Object userDetails) throws DataAccessException {
        return false;
    }

    /**
     * Login User
     * @param userDetails - object body that contains:
     *  username - the username
     *  password - the password
     *
     * @throws DataAccessException
     *
     * @return user object with specific username and password
     */
    public Object loginUser(Object userDetails) throws DataAccessException {
        return null;
    }

    /**
     * Removes all the users from the table
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removeAllUsers() throws DataAccessException {
        return false;
    }
}
