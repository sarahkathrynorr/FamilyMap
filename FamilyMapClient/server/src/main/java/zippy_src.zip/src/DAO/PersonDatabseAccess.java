package DAO;

import com.sun.org.apache.xpath.internal.operations.String;

/**
 * Persons Database Access Object -
 * Here new people are added to the world
 * and removed from the world (RIP)
 * and information on the person can be updated
 */
public class PersonDatabseAccess {
    /**
     * Remove a row in the person table
     *
     *  - Davey never even existed....
     *
     * @param personId - the numeric, unique id for the person
     *                 (if the person does not exist nothing will be removed)
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removePerson (int personId) throws DataAccessException {
        return false;
    }

    /**
     * Add a new person (row) to the persons table
     *
     * - we love new babies here
     * calls the updatePerson method
     * @param personDetails - object body that contains:
     *  personId - numeric Id of person's row to be changed
     *  firstName - if this is null the first name is not changed
     *  lastName - if this is null the last name is not changed
     *  gender - this really shouldn't be changed in the first place
     *  username - descendant of the person added
     *  father - numeric value for id of father, who is the daddy
     *  mother - numeric value for the id of mother, who is ur ma
     *  spouse - numeric value for the id of their sweetheart)
     *
     *               //TODO do I need to check if the person already exists?
     * @throws DataAccessException
     *
     * @return Object body of person just added
     */
    public Object addPerson(Object personDetails) throws DataAccessException {
        return null;
    }

    /**
     * Edit a row from a column that already exits
     *
     * @param personDetails - object body that contains:
     *  personId - numeric Id of person's row to be changed
     *  firstName - if this is null the first name is not changed
     *  lastName - if this is null the last name is not changed
     *  gender - this really shouldn't be changed in the first place
     *  username - descendant of the person added
     *  father - numeric value for id of father, who is the daddy
     *  mother - numeric value for the id of mother, who is ur ma
     *  spouse - numeric value for the id of their sweetheart
     *
     * - if person doesn't exist no columns will be added or changed
     *
     * @throws DataAccessException
     *
     * @return the Object body containing all the details about the person just updated
     */
    public Object updatePerson(Object personDetails) throws DataAccessException {
        return null;
    }

     /**
     * Retrieves everything the from a row in the person table
     *
     * @param personId - numeric Id of the person's row to get
     *
     * - if the personId does not exists then null is returned
     * @throws DataAccessException
     *
     * @return personObj - an object with all the parts of the person all nicely put together
     *
     */
    public Object getPerson(String personId) throws DataAccessException {
        return null;
    }

    /**
     * Retrieves all the data from the entire table of persons
     *
     * @param username - the username of the currentUser
     *
     * @return personsArray - an array a personObjects associated with the user
     *
     * @throws DataAccessException
     */
    public Object[] getAllPersons(String username) throws DataAccessException {
        return null;
    }

    /**
     * Removes all the persons from the table
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removeAllPersons() throws DataAccessException {
        return false;
    }
}