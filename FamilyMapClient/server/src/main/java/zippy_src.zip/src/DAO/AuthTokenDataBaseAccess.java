package DAO;

/**
 * A user can retrieve an authorization token through their username
 * used for updating, deleting, and adding to other tables
 */
public class AuthTokenDataBaseAccess {
    /**
     * remove an authToken from the table
     *
     * @param userDetails - an object body that contains:
     *  username - the person's Id to remove auth token
     *  personId - the person's numeric ID
     *
     * @throws DataAccessException
     *
     * @return a boolean success value
     */
    private boolean removeAuthToken(Object userDetails) throws DataAccessException {
        return false;
    }

    /**
     * adds a new auth token with a new user
     *
     * @param userDetails - object body that contains:
     *  username - this is created when a new user is created
     *  personId - numeric id for person
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    private boolean addAuthToken(Object userDetails) throws DataAccessException {
        return false;
    }

    /**
     * Retrieves the auth token according to either the username or personId
     *
     * @param userDetails - object body that contains:
     *  username - can be null as long as personId is not null
     *  personId - can be null as long as username is not null
     *
     * @return userAuthToken - Object string of the auth token if it exists
     * otherwise return null
     *
     * @throws DataAccessException
     */
    public Object getUserAuthToken(Object userDetails) throws DataAccessException {
        return new Object();
    }

    /**
     * clears all the auth tokens from the table
     *
     * @throws DataAccessException
     *
     * @return boolean success value
     */
    public boolean removeAllAuthTokens() throws DataAccessException {
        return false;
    }
}
