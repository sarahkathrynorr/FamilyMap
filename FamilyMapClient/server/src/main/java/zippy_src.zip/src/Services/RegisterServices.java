package Services;

import RequestResponse.UserRequest;
import RequestResponse.UserResponse;

/**
 * for registering a new user and thus a new person
 */

public class RegisterServices {
    /**
     * registers a new user by calling the AddUser DAO method
     * also adds a new person if the person is not already found in the DB using the addPerson DAO method
     * Also creates new AuthToken and adds that to the table
     *
     * @param userDetails - object body that contains:
     *
     * @throws DAO.DataAccessException
     *
     * @return the objectBody of the user just added
     *
     */
    public UserResponse registerUser(UserRequest userDetails) throws DAO.DataAccessException {
        return null;
    }
}
