package Services;

import RequestResponse.ClearResponse;
import RequestResponse.UserRequest;
import RequestResponse.UserResponse;

/**
 * services for removing or updating a user's information
 */
public class UserServices {
    /**
     * remove the user from the table
     *
     * @param username
     * @throws DAO.DataAccessException
     * @return Clear response value
     */
    public ClearResponse removeUser(String username) throws DAO.DataAccessException {
        return null;
    }

    /**
     * updates a single user from the table
     * @param user - the object body from user request of the user to be updated
     *             if parts of the object are null they are not updated
     *             if user is not found in the table nothing happens/is returned
     * @return the object body of the user that is updated
     * @throws DAO.DataAccessException
     */
    public UserResponse updateUser(UserRequest user) throws DAO.DataAccessException{
        return null;
    }
}
