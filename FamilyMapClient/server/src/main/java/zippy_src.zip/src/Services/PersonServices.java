package Services;

import RequestResponse.ClearResponse;
import RequestResponse.PersonRequest;
import RequestResponse.PersonResponse;

/**
 * Services for adding a single person, deleting a single person, updating a single person
 * I am a single person lol
 */
public class PersonServices {
    /**
     * adds a new person to the person table
     *
     * @param newPerson - object body that contains the details for the person to be added
     * @return the object body of the person is already in the table
     * @throws DAO.DataAccessException
     */
    public PersonResponse addPerson(PersonRequest newPerson) throws DAO.DataAccessException{
        return null;
    }

    /**
     * removes a person from the person table
     * @param personId - the ID for the person being removed
     * @return clear response from clear response object
     * @throws DAO.DataAccessException
     */
    public ClearResponse removePerson(String personId) throws DAO.DataAccessException {
        return null;
    }

    /**
     * updates a person in the persons table
     * @param person - the object body of the person to be updated
     *               if any part of the object is null it is not updated
     *               if the personId does not exists nothing is updated or returned
     * @return object body of the person updated
     * @throws DAO.DataAccessException
     */
    public PersonResponse updatePerson (PersonRequest person) throws DAO.DataAccessException{
        return null;
    }

    /**
     * returns the person based on the personId sent in
     * @param personId - type: String, the Id of the person to be returned
     * @return the object response body of the person to be returned
     * @throws DAO.DataAccessException
     */
    public PersonResponse getPerson(String personId) throws DAO.DataAccessException {
        return null;
    }

    /**
     * returns all the persons in the person table associated with a user's personId
     * @param personId - the user's personId
     * @return array of all the objects of persons to be returned
     * @throws DAO.DataAccessException
     */
    public PersonResponse[] getAllPersons(String personId) throws DAO.DataAccessException {
        return null;
    }
}
