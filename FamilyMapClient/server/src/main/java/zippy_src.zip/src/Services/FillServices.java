package Services;

import RequestResponse.*;

/**
 * services for filling in the tables with all the information given
 */
public class FillServices {
    /**
     * fill in the events table, loops through array and calls addUser in DAO.EventDatabaseAccess
     *
     * @param newEvents - arrayList of events to be added from request body
     *
     * @return arraylist of the events that were just added from response body
     */
    public EventResponse[] addEvents(EventRequest[] newEvents) {
        return null;
    }

    /**
     * fills the person table, loops through array and calls addPerson in DAO.PersonDatabaseAccess
     * @param newPersons - arrayList of the person to be added from the request body
     *
     * @return arrayList of the person that were just added from the response body
     */
    public PersonResponse[] addPersons(PersonRequest[] newPersons) {
        return null;
    }

    /**
     * fills the person table, loops through array and calls addUser in DAO.UserDatabaseAccess
     *
     * @param newUsers - arrayList of the users to be added from the request body
     *
     * @return arrayList of teh users that were just added from the response body
     */
    public UserResponse[] addUsers(UserRequest[] newUsers) {
        return null;
    }

    /**
     * fills the authToken table, loops through array and calls the addAuthToken in DAO.AuthTokenDatabaseAccess
     *
     * @param addAuth - arrayList fo the authToken to be added from the request body
     *
     * @return arrayList of the AuthTokens that were just adds from the response body
     */
    public AuthTokenResponse[] addAustTokens(AuthTokenRequest[] addAuth) {
        return null;
    }

}
