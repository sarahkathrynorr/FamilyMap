package Services;

import DAO.DataAccessException;
import RequestResponse.ClearResponse;

/**
 * services for clearing the tables in the family map database
 */
public class ClearServices {
    /**
     * remove all the person from the table
     * calls the clearAllEvents method in DAO
     *
     * @throws DAO.DataAccessException
     *
     * @return RequestResponse.clearResponse
     */
    public ClearResponse clearAllPersons() throws DataAccessException {
        return null;
    }

    /**
     * remove all the users from the table
     * calls the clearAllUsers method from the DAO
     *
     * @throws DAO.DataAccessException
     *
     * @return RequestResponse.clearResponse
     */
    public ClearResponse clearAllUsers() throws DataAccessException {
        return null;
    }

    /**
     * remove all the events from the table
     * calls the clearAllEvents method from the DAO
     *
     * @throws DAO.DataAccessException
     *
     * @return RequestResponse.clearResponse
     */
    public ClearResponse clearAllEvents() throws DataAccessException {
        return null;
    }

    /**
     * remove all the auth Tokens from the table
     * calls the clearAllAuthTokens from the DAO
     *
     * @throws DAO.DataAccessException
     *
     * @return RequestResponse.clearResponse
     */
    public ClearResponse clearAllAuthTokens() throws DataAccessException {
        return null;
    }

}
