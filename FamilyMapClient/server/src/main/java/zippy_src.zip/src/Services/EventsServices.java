package Services;

import RequestResponse.ClearResponse;
import RequestResponse.EventRequest;
import RequestResponse.EventResponse;

/**
 * services to get, remove, update events table
 */

public class EventsServices {
    /**
     * removes a single event
     *
     * @param eventId (EventRequest.getEventId())
     * @return clear response object body - a message that says it's clear
     */
    public ClearResponse removeEvent(String eventId) {
        return null;
    }

    /**
     * adds a new event to the table
     *
     * @param newEvent - object that contains event details - see eventRequest
     * @return RequestResponse.EventResponse
     */
    public EventResponse addEvent(Object newEvent) {
        return null;
    }


    /**
     * updates an event already in the table
     *
     * @param event - object that contains event details, see eventRequest
     *              if parts of event object are null they are not changed
     *              if event ID is not found nothing happens
     * @return RequestResponse.EventResponse
     */
    public EventResponse updateEvent(EventRequest event) {
        return null;
    }

    /**
     * returns a single event based on Event Id
     *
     * @param eventId - the eventId of event to be returned, string
     * @return RequestResponse.EventResponse
     */
    public EventResponse getEvent(String eventId) {
        return null;
    }

    /**
     * returns all the events related to a user
     *
     * @param personId - the personId of the user that the events are related to
     * @return the array of Objects that contain events
     */
    public EventResponse[] getAllEvents(String personId) {
        return null;
    }
}
