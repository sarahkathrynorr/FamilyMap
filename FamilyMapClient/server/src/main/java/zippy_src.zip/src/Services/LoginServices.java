package Services;

import RequestResponse.RequestLogin;
import RequestResponse.ResultLogin;

/**
 * services for logging in
 */
public class LoginServices {
    /**
     * login service - logs user in and creates new auth token
     * calls the and login DAO method and then createAuthToken DAO method
     *
     * @param userDetails - login request object of user
     *
     * @throws DAO.DataAccessException
     *
     * @return Login Response object
     */
    public ResultLogin login(RequestLogin userDetails) throws DAO.DataAccessException {
        return null;
    }
}