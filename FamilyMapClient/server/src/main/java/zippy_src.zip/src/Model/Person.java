package Model;

/**
 * model class for person
 * includes getters and setters
 */
public class Person {
    /**
     * personId is of type string
     */
    private String personId;
    /**
     * descendant is of type string
     */
    private String descendant;
    /**
     * firstName is of type string
     */
    private String firstName;
    /**
     * lastName is of type string
     */
    private String lastName;
    /**
     * gender is of type string
     * can only be "m" or "f"
     */
    private String gender;
    /**
     * father is of type string
     * may be a null value
     */
    private String father;
    /**
     * mother is of type string
     * may be a null value
     */
    private String mother;
    /**
     * spouse is of type string
     * may be a null value
     */
    private String spouse;


    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public void setDescendant(String descendant) {
        this.descendant = descendant;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setMother(String mother) {
        this.mother = mother;
    }

    public void setSpouse(String spouse) {
        this.spouse = spouse;
    }

    public String getDescendant() {
        return descendant;
    }

    public String getFather() {
        return father;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getGender() {
        return gender;
    }

    public String getLastName() {
        return lastName;
    }

    public String getMother() {
        return mother;
    }

    public String getPersonId() {
        return personId;
    }

    public String getSpouse() {
        return spouse;
    }
}
