package Model;
/**
 * model class for Event object
 * includes getters and setters
 * contains eventId, username, personId, latitude, longitude, country, city, eventType, year(int)
 * except for year all are strings
 */
public class Event {
    /**
     * eventId is of type string
     */
    private String eventId; //non empty string
    /**
     * username is of type string
     */
    private String username;
    /**
     * personId is of type string
     */
    private String personId;
    /**
     * latitude is of type string
     */
    private String latitude; //ints?
    /**
     * longitude is of type string
     */
    private String longitude;
    /**
     * country is of type string
     */
    private String country;
    /**
     * city is of type string
     */
    private String city;
    /**
     * eventType is of type string
     */
    private String eventType; //birth, baptism, marriage, etc...
    /**
     * year is of type int
     */
    private int year;

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getYear() {
        return year;
    }

    public String getEventId() {
        return eventId;
    }

    public String getUsername() {
        return username;
    }

    public String getPersonId() {
        return personId;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }

    public String getEventType() {
        return eventType;
    }
}
