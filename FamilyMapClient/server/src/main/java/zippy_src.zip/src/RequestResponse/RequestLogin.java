package RequestResponse;
/**
 * request login object
 * includes a username and a password string
 */
public class RequestLogin {

    /**
     * username - type String
     */
    private String username;
    /**
     * password - type String
     */
    private String password;

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

