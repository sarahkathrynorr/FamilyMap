package RequestResponse;
/**
 * cleared
 */
public class ClearResponse {

    /**
     * message to display that a deletion was successful, type String
     */
    private String response = "Clear succeeded";
}
