package RequestResponse;

import Model.User;
/**
 * the result object body for the login
 * contains a User user data member
 */
public class ResultLogin {

    /**
     * user - User object
     */
    private User user;

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
