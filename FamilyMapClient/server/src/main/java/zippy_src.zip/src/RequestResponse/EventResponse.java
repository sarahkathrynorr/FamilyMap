package RequestResponse;

import Model.Event;
/**
 * response to Event request
 * includes Strings for not found, and empty
 * and an Event to return
 */
public class EventResponse {
    /**
     * String notFoundMsg to display if the event is not found in the Database
     */
    private String notFoundMsg = "Event not Found";
    /**
     * event is of type Event
     */
    private Event event;

    public Event getEvent() {
        return event;
    }

    public String getNotFoundMsg() {
        return notFoundMsg;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public void setNotFoundMsg(String notFoundMsg) {
        this.notFoundMsg = notFoundMsg;
    }
}
