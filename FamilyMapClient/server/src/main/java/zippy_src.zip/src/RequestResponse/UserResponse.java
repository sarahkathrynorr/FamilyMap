package RequestResponse;

import Model.User;
/**
 * response to User request
 * includes Strings for not found, and empty
 * and an User to return
 */
public class UserResponse {
    /**
     * notFoundMsg - String to display if the User is not found in the database
     */
    private String notFoundMsg = "User not Found";
    /**
     * user - User object
     */
    private User user;

    public User getUser() {
        return user;
    }

    public String getNotFoundMsg() {
        return notFoundMsg;
    }

    public void setPerson(User person) {
        this.user = person;
    }
}
