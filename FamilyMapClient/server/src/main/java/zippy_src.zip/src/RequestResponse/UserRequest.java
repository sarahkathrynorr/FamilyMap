package RequestResponse;

import Model.User;
/**
 * user request
 * contains data members Person object
 */
public class UserRequest {
    private User user;

    public User getUser() {
        return user;
    }

    public void setPerson(User user) {
        this.user = user;
    }
}
