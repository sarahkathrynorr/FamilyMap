package RequestResponse;

import Model.Person;
/**
 * response to Event request
 * includes Strings for not found, and empty
 * and an Person to return
 */
public class PersonResponse {
    /**
     * String notFoundMsg is to display that the Person is not in the database
     */
    private String notFoundMsg = "Person not Found";
    /**
     * person is of type Person
     */
    private Person person;

    public Person getPerson() {
        return person;
    }

    public String getNotFoundMsg() {
        return notFoundMsg;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
