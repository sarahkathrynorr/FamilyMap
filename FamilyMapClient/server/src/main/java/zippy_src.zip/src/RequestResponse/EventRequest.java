package RequestResponse;
import Model.Event;
/**
 * data members are the eventId and the Event event object
 */
public class EventRequest {
    /**
     * eventId is of type string
     */
    private String eventId;
    /**
     * event is of type Event
     */
    private Event event;

    public Event getEvent() {
        return event;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
