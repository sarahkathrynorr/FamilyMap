package RequestResponse;

import Model.Person;
/**
 * person request
 * contains data members Person object
 */
public class PersonRequest {
    /**
     * person is of type Person
     */
    private Person person;

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
