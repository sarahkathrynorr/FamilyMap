package RequestResponse;

public class LoadResponse {
    private String message;

    public LoadResponse(String message) {
        this.message = message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
